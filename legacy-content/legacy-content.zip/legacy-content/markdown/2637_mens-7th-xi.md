   
  
![Honour-Board-Mens-Seventh-XI-](http://mentonehockey.org.au/wp-content/uploads/2017/06/Honour-Board-Mens-Seventh-XI-.png)

Year | Player | Grade  
---|---|---  
1994 | Darren Parkes | Grass Competition  
1995 | Darren Parkes | Grass Competition  
1996 | John Callaghan | Grass Competition  
1997 | * | *  
1998 | * | *  
1999 | * | *  
2000 |  |   
2001 |  |   
2002 |  |   
2003 |  |   
2004 |  |   
2005 |  |   
2006 |  |   
2007 |  |   
2008 |  |   
2009 |  |   
2010 |  |   
2011 |  |   
2012 |  |   
2013 |  |   
2014 |  |   
2015 |  |   
2016 |  |   
2017 |  |   
2018 |  |   
2019 |  |   
2020 |  |   
2021 |  |   
2022 |  |   
2023 |  |   
2024 |  |   
2025 |  |   
2026 |  |   
2027 |  |   
2028 |  |   
2029 |  |   
2030 |  | 
